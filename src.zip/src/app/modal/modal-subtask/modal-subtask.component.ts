import { Component } from '@angular/core';

@Component({
  selector: 'app-modal-subtask',
  templateUrl: './modal-subtask.component.html',
  styleUrls: ['./modal-subtask.component.css']
})
export class ModalSubtaskComponent {

}
