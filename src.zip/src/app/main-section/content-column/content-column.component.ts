import { Component } from '@angular/core';

@Component({
  selector: 'app-content-column',
  templateUrl: './content-column.component.html',
  styleUrls: ['./content-column.component.css']
})
export class ContentColumnComponent {

}
